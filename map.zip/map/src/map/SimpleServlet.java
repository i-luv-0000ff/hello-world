package map;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import action.NosqlCrud;
import action.NosqlMgr;
import rest.NetClientGet;

/**
 * Servlet implementation class SimpleServlet
 */
@WebServlet("/SimpleServlet")
public class SimpleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SimpleServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String getTrack = request.getParameter("track");
		String action = request.getParameter("act");
		if (action == null || "".equals(action)) {
			response.getWriter().print("nodata");
		} else {

			if ("track".equals(action)) {
				
				//JsonObject fromClient = new Gson().toJsonTree(getTrack).getAsJsonObject();
				
				String co= request.getParameter("coordinate");
				String danger= request.getParameter("panic");
				String warning= request.getParameter("danger");
				String warningZone= request.getParameter("dangerZone");
				String id=request.getParameter("id");

				JsonObject trakDetails = new JsonObject();
//				trakDetails.addProperty("_id", fromClient.get("id").getAsString());
//				trakDetails.addProperty("name", fromClient.get("name").getAsString());
//				trakDetails.addProperty("panic", fromClient.get("panic").getAsString());
//				String coOrdinates[] = fromClient.get("location").getAsString().split(",");
				
				trakDetails.addProperty("_id", id);
				trakDetails.addProperty("danger", danger);
				trakDetails.addProperty("warning", warning);
				String coOrdinates[] =co.split(",");

				/*
				 * "geometry": { "type": "Point", "coordinates": [
				 * -77.12911152370515, 38.79930767201779 ] }
				 */

				JsonObject path = new JsonObject();
				JsonObject geObject = new JsonObject();

				JsonArray coordinates = new JsonArray();
				Gson gson = new Gson();

				geObject.addProperty("type", "Point");
				coordinates.add(gson.toJsonTree(coOrdinates[0]));
				coordinates.add(gson.toJsonTree(coOrdinates[1]));
				geObject.add("coordinates", coordinates);

				path.add("geometry", geObject);

				JsonArray pathArray = new JsonArray();
				pathArray.add(path);

				trakDetails.add("path", pathArray);

				// save the path
				NosqlCrud crud = new NosqlCrud();
				
				System.out.println(trakDetails);

				JsonObject jo=crud.create(NosqlMgr.getDB(), trakDetails);

				System.out.println(jo);
				response.getWriter().print(jo);
				
				
			} else if ("showTrack".equals(action)) {
				NetClientGet clientGet =new NetClientGet();
				String userId=request.getParameter("userId");
				String data=clientGet.GetData(clientGet.getDataURL(userId));
				
				
				//tack latest position
				JsonObject obj =new JsonParser().parse(data).getAsJsonObject();
				
				JsonObject responseJson =clientGet.getNearRadius(obj);
				response.getWriter().print(responseJson);	
				
			} 
			

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
