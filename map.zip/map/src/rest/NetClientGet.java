package rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javafx.print.JobSettings;

public class NetClientGet {

	public String GetData(String urlStr) {
		String output = null, output2 = "nothing";
		try {

			// URL url = new URL(
			// "https://7864782a-f7bb-4d28-b890-e62eb8c4dc8c-bluemix.cloudant.com/geotry/_design/geoind/_geo/newGeoIndex?lat=38.896109869098936&lon=-77.01714277267456&radius=100&limit=20&relation=contains&nearest=true");
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			Authenticator myAuth = new Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("7864782a-f7bb-4d28-b890-e62eb8c4dc8c-bluemix",
							"314659f119e92b39766fe03e6f1b30e8975de83e062ca7f51aff011317e9857a".toCharArray());
				}
			};
			Authenticator.setDefault(myAuth);

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				// output=output+output;
				// System.out.println("in");
				// System.out.println(output);
				output2 = output;

			}

			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();

		}
		// System.out.println("out");
		return output2;
	}

	public JsonObject synData(JsonObject jo) {
		JsonObject output = new JsonObject();

		// take last path
		JsonArray jarray = jo.get("path").getAsJsonArray();
		JsonObject last = jarray.get(jarray.size() - 1).getAsJsonObject();

		// check danger Key
		//output.addProperty("danger", jo.get("danger").getAsBoolean());

		// check warning key
		// call to radius
		JsonArray geometry = last.get("geometry").getAsJsonObject().get("coordinates").getAsJsonArray();

		String lat = geometry.get(0).getAsString();
		String lng = geometry.get(0).getAsString();

		String row = this.GetData(this.getWarningURL(lat, lng));

		// JsonObject rowObj= new Gson().toJsonTree(row).getAsJsonObject();
		JsonParser jsonParser = new JsonParser();
		JsonObject rowObj = jsonParser.parse(row).getAsJsonObject();
		int size = rowObj.get("rows").getAsJsonArray().size();

		if (size > 0) {
			output.addProperty("warning", true);
		} else {
			output.addProperty("warning", false);
		}

		// output.add("location", last);

		return output;
	}

	public JsonObject getNearRadius(JsonObject jo) {
		JsonObject output = new JsonObject();

		// take last path
		JsonArray jarray = jo.get("path").getAsJsonArray();
		JsonObject last = jarray.get(jarray.size() - 1).getAsJsonObject();

		// check danger Key
		if (jo.get("danger").getAsBoolean()) {
			output.addProperty("danger", true);
		} else {
			output.addProperty("danger", false);
		}

		// check warning key
		// call to radius
		JsonArray geometry = last.get("geometry").getAsJsonObject().get("coordinates").getAsJsonArray();

		String lat = geometry.get(0).getAsString();
		String lng = geometry.get(0).getAsString();

		String row = this.GetData(this.getWarningURL(lat, lng));

		// JsonObject rowObj= new Gson().toJsonTree(row).getAsJsonObject();
		JsonParser jsonParser = new JsonParser();
		JsonObject rowObj = jsonParser.parse(row).getAsJsonObject();
		int size = rowObj.get("rows").getAsJsonArray().size();

		if (size > 0) {
			output.addProperty("warning", true);
		} else {
			output.addProperty("warning", false);
		}

		output.add("location", last.get("geometry").getAsJsonObject().get("coordinates").getAsJsonArray());

		return output;

	}

	public String getDataURL(String userId) {
		return "https://7864782a-f7bb-4d28-b890-e62eb8c4dc8c-bluemix.cloudant.com/sample_nosql_db/" + userId;
	}

	public String getWarningURL(String lat, String lng) {
		return "https://7864782a-f7bb-4d28-b890-e62eb8c4dc8c-bluemix.cloudant.com/geotry/_design/geoind/_geo/newGeoIndex?lat="
				+ lat + "&lon=" + lng + "&radius=100&limit=20&relation=contains&nearest=true";
	}

	// http://localhost:8080/RESTfulExample/json/product/get
	public static void main(String[] args) {

		NetClientGet clientGet = new NetClientGet();

		System.out.print(clientGet.GetData("sf"));
		/*
		 * try {
		 * 
		 * URL url = new URL(
		 * "https://7864782a-f7bb-4d28-b890-e62eb8c4dc8c-bluemix.cloudant.com/sample_nosql_db/women_2"
		 * ); HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		 * conn.setRequestMethod("GET"); conn.setRequestProperty("Accept",
		 * "application/json"); Authenticator myAuth = new Authenticator() {
		 * 
		 * @Override protected PasswordAuthentication
		 * getPasswordAuthentication() { return new PasswordAuthentication(
		 * "7864782a-f7bb-4d28-b890-e62eb8c4dc8c-bluemix",
		 * "314659f119e92b39766fe03e6f1b30e8975de83e062ca7f51aff011317e9857a".
		 * toCharArray()); } }; Authenticator.setDefault(myAuth);
		 * 
		 * 
		 * 
		 * 
		 * if (conn.getResponseCode() != 200) { throw new RuntimeException(
		 * "Failed : HTTP error code : " + conn.getResponseCode()); }
		 * 
		 * BufferedReader br = new BufferedReader(new InputStreamReader(
		 * (conn.getInputStream())));
		 * 
		 * String output; System.out.println("Output from Server .... \n");
		 * while ((output = br.readLine()) != null) {
		 * 
		 * System.out.println(output); }
		 * 
		 * conn.disconnect();
		 * 
		 * } catch (MalformedURLException e) {
		 * 
		 * e.printStackTrace(); } catch (IOException e) {
		 * 
		 * e.printStackTrace();
		 * 
		 * }
		 */

	}

}