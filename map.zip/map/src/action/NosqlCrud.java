package action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Part;

import com.cloudant.client.api.Database;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.internal.LinkedTreeMap;

import rest.NetClientGet;

public class NosqlCrud {

	public JsonObject create(Database db, JsonObject trakDetails) throws IOException {
		
		String id = "";
		HashMap<String, Object> obj = null;
		try {
			id = trakDetails.get("_id").getAsString();
		

		// check if document exist
		 obj = (id == null) ? null : db.find(HashMap.class, id);
		} catch (Exception ex) {

		}
		if (obj == null) {
			// if new document

			//id = trakDetails.get("name").getAsString() + String.valueOf(System.currentTimeMillis());

			// create a new document
			System.out.println("Creating new document with id : " + id);
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("name", trakDetails.get("_id").getAsString());
			data.put("_id", id);
			data.put("danger", trakDetails.get("danger").getAsString());
			// path details
			data.put("path", trakDetails.get("path").getAsJsonArray());
			
			data.put("creation_date", new Date().toString());
			
			System.out.println("new entry"+data);
			db.save(data);

		} else {
			// if existing document
			// attach the attachment object

			// update other fields in the document
			obj = db.find(HashMap.class, id);
			
			System.out.println("new entry"+obj);
			
			obj.put("danger", trakDetails.get("danger").getAsBoolean());
			obj.put("path", trakDetails.get("path").getAsJsonArray());
			db.update(obj);
		}

		obj = db.find(HashMap.class, id);
		System.out.println("Final"+obj);

		JsonObject resultObject = new NetClientGet().synData(trakDetails);
		
		

		return resultObject;
	}
	
	
	
	/*private JsonObject toJsonObject(HashMap<String, Object> obj) {
		JsonObject jsonObject = new JsonObject();
		LinkedTreeMap<String, Object> pathArray = (LinkedTreeMap<String, Object>) obj.get("path");
		if (pathArray != null && pathArray.size() > 0) {
			JsonArray attachmentList = getAttachmentList(pathArray, obj.get("_id") + "");
			jsonObject.add("attachements", attachmentList);
		}
		jsonObject.addProperty("id", obj.get("_id") + "");
		jsonObject.addProperty("name", obj.get("name") + "");
		jsonObject.addProperty("value", obj.get("value") + "");
		return jsonObject;
	}
	
	private JsonArray getAttachmentList(LinkedTreeMap<String, Object> attachmentList, String docID) {
		JsonArray attachmentArray = new JsonArray();
		

		for (int i=0;i<attachmentArray.size();i++) {
			LinkedTreeMap<String, Object> attach = (LinkedTreeMap<String, Object>) attachmentList.get(key);

			JsonObject attachedObject = new JsonObject();
			// set the content type of the attachment
			attachedObject.addProperty("content_type", attach.get("content_type").toString());
			// append the document id and attachment key to the URL
			attachedObject.addProperty("url", "attach?id=" + docID + "&key=" + key);
			// set the key of the attachment
			attachedObject.addProperty("key", key + "");

			// add the attachment object to the array
			attachmentArray.add(attachedObject);
		}

		return attachmentArray;
	}
	*/
	
	
	public static void main(String args[]) {
	
		NosqlCrud crud=new NosqlCrud();
		JsonObject trakDetails=new JsonObject();
		trakDetails.addProperty("_id", "5678");
		trakDetails.addProperty("name", "women_2");
		trakDetails.addProperty("danger", false);
		
		/*
		 * "geometry": { "type": "Point", "coordinates": [
		 * -77.12911152370515, 38.79930767201779 ] }
		 */

		JsonObject path=new JsonObject();
		JsonObject geObject=new JsonObject();
		
		JsonArray coordinates =new JsonArray();
		Gson gson =new Gson();
		
		geObject.addProperty("type","Point");
		coordinates.add(gson.toJsonTree("-77.12911152370515"));
		coordinates.add(gson.toJsonTree("38.79930767201779"));
		geObject.add("coordinates",coordinates);
		
		
		
	
		
		path.add("geometry", geObject);
		
		JsonArray pathArray=new JsonArray();
		pathArray.add(path);
		
		trakDetails.add("path", pathArray);
		
		System.out.println(trakDetails);
		
		try {
			crud.create(NosqlMgr.getDB(), trakDetails);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
