package action;

import java.util.Map.Entry;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.cloudant.client.api.ClientBuilder;
import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.org.lightcouch.CouchDbException;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;

public class NosqlMgr {

	private static CloudantClient cloudant = null;
	private static Database db = null;

	private static String databaseName = "sample_nosql_db";

	private static String user = "7864782a-f7bb-4d28-b890-e62eb8c4dc8c-bluemix";
	private static String password = "314659f119e92b39766fe03e6f1b30e8975de83e062ca7f51aff011317e9857a";

	private static void initClient() {
		if (cloudant == null) {
			synchronized (CloudantClientMgr.class) {
				if (cloudant != null) {
					return;
				}
				cloudant = createClient();

			} // end synchronized
		}
	}

	private static CloudantClient createClient() {

		JsonObject obj = new JsonObject();

		String serviceName = null;

		try {
			CloudantClient client = ClientBuilder.account(user).username(user).password(password).build();
			return client;
		} catch (CouchDbException e) {
			throw new RuntimeException("Unable to connect to repository", e);
		}
	}

	public static Database getDB() {
		System.out.println("Started call getDB");
		if (cloudant == null) {
			initClient();
		}

		if (db == null) {
			try {
				db = cloudant.database(databaseName, true);
			} catch (Exception e) {
				throw new RuntimeException("DB Not found", e);
			}
		}

		return db;
	}

	private NosqlMgr() {
	}

	public static void main(String args[]) {

		NosqlMgr mgr = new NosqlMgr();
		System.out.println("Started call");

		JsonObject resultObject = new JsonObject();
		JsonArray jsonArray = new JsonArray();

		try {
			List<HashMap> allDocs = mgr.getDB().getAllDocsRequestBuilder().includeDocs(true).build().getResponse()
					.getDocsAs(HashMap.class);

			for (HashMap doc : allDocs) {
				HashMap<String, Object> obj = db.find(HashMap.class, doc.get("_id") + "");
				JsonObject jsonObject = new JsonObject();

				jsonObject.addProperty("id", obj.get("_id") + "");
				jsonObject.addProperty("name", obj.get("name") + "");
				jsonObject.addProperty("value", obj.get("value") + "");

				jsonArray.add(jsonObject);
			}
			System.out.println(jsonArray);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
