package com.yumeservice;

import java.io.Serializable;

public class Iodetails implements Serializable{
	private static final long serialVersionUID = 199447570016823436L;
	private String name;
	private String shortName1;
	private String impression;
	private String dayOpen;
	private String dayClose;
	private Integer goal;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShortName1() {
		return shortName1;
	}
	public void setShortName1(String shortName1) {
		this.shortName1 = shortName1;
	}
	public String getImpression() {
		return impression;
	}
	public void setImpression(String impression) {
		this.impression = impression;
	}
	public String getDayOpen() {
		return dayOpen;
	}
	public void setDayOpen(String dayOpen) {
		this.dayOpen = dayOpen;
	}
	public String getDayClose() {
		return dayClose;
	}
	public void setDayClose(String dayClose) {
		this.dayClose = dayClose;
	}
	public Integer getGoal() {
		return goal;
	}
	public void setGoal(Integer goal) {
		this.goal = goal;
	}
}
