package com.yumeservice;

import java.util.List;

public class Response<T> {
	private T entity;
	private List<T> entityCollection;
	public T getEntity() {
		return entity;
	}
	public void setEntity(T entity) {
		this.entity = entity;
	}
	public List<T> getEntityCollection() {
		return entityCollection;
	}
	public void setEntityCollection(List<T> entityCollection) {
		this.entityCollection = entityCollection;
	}
	
}
