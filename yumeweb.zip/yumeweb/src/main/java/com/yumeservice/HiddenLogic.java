package com.yumeservice;

import java.util.ArrayList;
import java.util.List;

public class HiddenLogic {
	public static List<Iodetails> getList() {
		List<Iodetails> response=new ArrayList<Iodetails>();
		
		Iodetails detail=new Iodetails();
		detail.setName("YUME");
		detail.setShortName1("Yume");
		detail.setImpression("100");
		detail.setDayOpen("152");
		detail.setDayClose("153");
		detail.setGoal(68);
		response.add(detail);
		
		detail=new Iodetails();
		detail.setName("BOSCH");
		detail.setShortName1("Bosch");
		detail.setImpression("200");
		detail.setDayOpen("203");
		detail.setDayClose("205");
		detail.setGoal(99);
		response.add(detail);

		detail=new Iodetails();
		detail.setName("DELL");
		detail.setShortName1("Dell");
		detail.setImpression("300");
		detail.setDayOpen("303");
		detail.setDayClose("353");
		detail.setGoal(5);
		response.add(detail);
		
		detail=new Iodetails();
		detail.setName("SAMSUNG");
		detail.setShortName1("Samsung");
		detail.setImpression("400");
		detail.setDayOpen("403");
		detail.setDayClose("453");
		detail.setGoal(65);
		response.add(detail);
		
		detail=new Iodetails();
		detail.setName("BOSS");
		detail.setShortName1("Boss");
		detail.setImpression("500");
		detail.setDayOpen("503");
		detail.setDayClose("553");
		detail.setGoal(45);
		response.add(detail);
		
		return response;
	}
}
