package com.yumeservice;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.spring.scope.RequestContextFilter;

public class BaseService extends ResourceConfig {
		public BaseService() {
			register(RequestContextFilter.class);
			packages("com.yumeservice");
			register(JacksonFeature.class);
			register(RequestHandlers.class);
		}
}
