$(document).ready(function() {
    $.ajax({
        url: "http://localhost:8080/services/ioservice/getIOdetails"
    }).then(function(data) {
        data.entityCollection.forEach(
            function contentCreator(item, index) {
                $("#accordion").html($("#accordion").html() +
                    "<h3><div style=\"display: inline-block;\"><div class=\"textDiv\">" + item.name + "</div><div class=\"progressPer\">" + item.goal + "%" + "<div class=\"myProgress\"><div id=\"bar" + index + "\" class=\"myBar\"></div></div></div></div></h3><div><img src=\"chart0.jpg\"/><div class=\"table\"><div class=\"tr\"><span class=\"td blu\">" + item.shortName1 + "</span></div><div class=\"tr\"><span class=\"td\">Company Name</span></div><div class=\"tr\"><span class=\"td blu\">" + item.impression + "</span><span class=\"td blu\">" + item.dayOpen + "</span><span class=\"td blu\">" + item.dayClose + "</span></div><div class=\"tr\"><span class=\"td\">Impression</span><span class=\"td\">Day Open</span><span class=\"td\">Day Close</span></div></div></div>"
                );

                $("#bar" + index).css("width", item.goal + "%");
            });
        $("#accordion").accordion({
            collapsible: true,
            heightStyle: "content"
        });
        $("#search").bind("enterKey", function(e) {
            $(".textDiv").each(function(i) {
                if ($("#search").val().toLowerCase() === $(this).text().toLowerCase()) {
                    $(this).click();
                    $(this).focus();
                    $(window).scrollTo($(this));
                }
            });
        });
        $("#search").keyup(function(e) {
            if (e.keyCode == 13) {
                $(this).trigger("enterKey");
            }
        });

    });
});
